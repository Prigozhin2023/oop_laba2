class Validator:

    def __init__(self):
        pass